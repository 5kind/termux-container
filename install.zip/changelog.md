### v1.4 - 2024.12.20
* Allow customize docker service by start-docker.sh;
* Auto Start/Stop Android system by container-completed.sh.
* Auto disable doze by container-completed.sh.

### v1.3 - 2024.12.01
* Allow use password to unlock devices by locksettings-verify.

### v1.2 - 2024.11.25
* Refactor and improve the code structure

### v1.1 - 2023.12.24
* Mount tmpfs to /data/docker/run

### v1.0 - 2023.12.15
* Initial release